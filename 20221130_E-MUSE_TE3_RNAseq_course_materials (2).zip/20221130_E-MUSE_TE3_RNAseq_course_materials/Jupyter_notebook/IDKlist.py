
import os

def k2ID(data_path,results_path):
    print("input data path :",data_path)
    print("input results path :",results_path)
    print()
    
    IDKfile = "Meta_Kegg.txt"
    IDKfile_path = data_path +"/"+ IDKfile

    #Ouverture en lecture du fichier contenant la la liste des ID et K numbers
    #Création du dictionnaire ID

    with open(IDKfile_path,'r') as file_in:
        dicID = {}
        K=""
        ID=""
        line=file_in.readline()
        while line != "":  
    #Enregistrement des valeurs K
            K=line.split()[1]
    #Enregistrement des clés           
            ID=line.split()[0]
            dicID[ID]=[K]          
            line=file_in.readline()

    import csv
    IDfile = "geneIDs.txt"
    IDfile_path = data_path +"/"+ IDfile
    IDKlist = "IDKlist.tsv"
    IDKlist_path = results_path +"/"+ IDKlist
    #Ouverture en lecture du fichier contenant la liste des ID
    #Ouverture en écriture du fichier contenant les ID et Knumbers
    with open(IDfile_path,'r') as file_in, open(IDKlist_path,'w', newline='') as file_out:
        fields=["1","2"]
        file_writer=csv.DictWriter(file_out,fieldnames=fields,delimiter="\t",quotechar="",quoting=csv.QUOTE_NONE)
        ID=""
        knumber=""
        for line in file_in:
            line=line.split()
            ID=line[0]
            ID="".join(ID)
    #Recherche dans le dictionnaire des knumbers pour chaque ID
            if line[0] in dicID:
                knumber=dicID[ID]
                knumber="".join(knumber)
    # Ecriture dans le fichier de sortie
                file_writer.writerow({"1":ID,"2":knumber})
            else:
                file_writer.writerow({"1":ID,"2":"NA"})
    print('job done !')

if __name__ == "__main__":
    print()
    data_path = "data"
    results_path = "results"
    try:
        os.mkdir(results_path)
    except:
        pass
    k2ID(data_path,results_path) 
