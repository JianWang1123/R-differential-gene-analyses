﻿import os

def annot2list(data_path,results_path):
    print("input data path :",data_path)
    print("input results path :",results_path)
    print()
    
    annotfile = "annotations.txt"
    annotfile_path = data_path +"/"+ annotfile

    #Opening kegg file for reading
    #Dictionary creation
    with open(annotfile_path,'r') as file_in:
        dic = {}
        ID=""
        annotation=""
        line=file_in.readline()
        while line != "":  
    #Keys and values registration:
            ID = line.split("\t")[0]
            annotation= line.strip().split("\t")
            annotation ="/".join(annotation)
            dic[ID]=[annotation]
            line=file_in.readline()

    import csv
    IDfile = "geneIDs.txt"
    IDfile_path = data_path +"/"+ IDfile
    IDannotfile = "IDAnnot.tsv"
    IDannotfile_path = results_path +"/"+ IDannotfile  
    #Ouverture en lecture du fichier contenant la liste des ID: sys.argv[2]
    #Ouverture en écriture du fichier contenant les ID et annotations
    with open(IDfile_path,'r') as file_in, open(IDannotfile_path,'w', newline='') as file_out:
        fields=["1","2"]
        file_writer=csv.DictWriter(file_out,fieldnames=fields,delimiter="\t",quoting=csv.QUOTE_ALL)
        ID=""
        Annot=""
        for line in file_in:
            line=line.strip().split()
            ID=line[0]
        #Recherche dans le dictionnaire des ID
            if line[0] in dic:
                Annot=dic[ID]
        # Ecriture dans le fichier de sortie
                file_writer.writerow({"1":ID,"2":Annot})
            else:
                file_writer.writerow({"1":ID,"2":"NA"})
    print('job done !') 

if __name__ == "__main__":
    print()
    data_path = "data"
    results_path = "results"
    try:
        os.mkdir(results_path)
    except:
        pass
    annot2list(data_path,results_path)     
