﻿import os

def k2list(data_path,results_path):
    print("input data path :",data_path)
    print("input results path :",results_path)
    print()
    
    keggfile = "ko00001.keg"
    keggfile_path = data_path +"/"+ keggfile

    #Opening kegg file for reading
    #Dictionary creation
    with open(keggfile_path,'r') as file_in:
        dic = {}
        A=""
        B=""
        C=""
        D=""
        k=""
        save=True
        line=file_in.readline()
        while line != "":  
    #Enregistrement des valeurs A, B, C, D
            if line.startswith("A09150"):
                save=False
            if line.startswith("A09160"):
                save=False
            if line.startswith("A09180"):
                save=False
            if line.startswith("A"):
                A=line.split()[1:]
                A=" ".join(A)
            if line.startswith("B"):
                B=line.split()[2:]
                B=" ".join(B)
                B=B.split(",")
                B=" ".join(B)
            if line.startswith("C"):
                C=line.split()[2:]
                C=" ".join(C)
                C=C.split(",")
                C=" ".join(C)
            if line.startswith("D"):
                D=line.split()[2:]
                D=" ".join(D)
                D=D.split(";")
                D= D[:]
                D=" ".join(D)
                D=D.split(",")
                D=" ".join(D)
                D=D.split("/")
                D=" ".join(D)
    #Enregistrement des clés
                if save==True:            
                    k=line.split()[1]           
                    if k in dic:
                        dic[k]+=[(C)]
                    else:
                        dic[k]=[(C)]
                else:
                    pass
            line=file_in.readline()

    import csv
    IDKfile = "Meta_Kegg.txt"
    IDKfile_path = data_path +"/"+ IDKfile
    IDKhierarchy = "MetaKhierarchy.tsv"
    IDKhierarchy_path = results_path +"/"+ IDKhierarchy
    #Ouverture en lecture du fichier contenant la liste des Knumbers: sys.argv[2]
    #Ouverture en écriture du fichier contenant les Knumbers et la hiérarchie
    with open(IDKfile_path,'r') as file_in, open(IDKhierarchy_path,'w', newline='') as file_out:
        fields=["1","2","3"]
        file_writer=csv.DictWriter(file_out,fieldnames=fields,delimiter="\t",quotechar="",quoting=csv.QUOTE_NONE)
        ID=""
        knumber=""
        hierarchy=""
        for line in file_in:
            line=line.split()
            ID=line[0]
            knumber=line[1]
            knumber="".join(knumber)
    #Recherche dans le dictionnaire des knumbers pour chaque ID
            if knumber in dic:
                hierarchy=dic[knumber]
                for i in range(len(hierarchy)):
    # Ecriture dans le fichier de sortie
                    file_writer.writerow({"1":ID,"2":knumber,"3":hierarchy[i]}) 
            else:
                file_writer.writerow({"1":ID,"2":"NA","3":"NA"})
    print('job done !') 
          

if __name__ == "__main__":
    print()
    data_path = "data"
    results_path = "results"
    try:
        os.mkdir(results_path)
    except:
        pass
    k2list(data_path,results_path)    
