import os

def path2list(results_path):
    
    print("input results path :",results_path)
    print()
    
    IDKhierarchy = "MetaKhierarchy.tsv"
    IDKhierarchy_path = results_path +"/"+ IDKhierarchy

    #Ouverture en lecture du fichier contenant la hiérarchie kegg
    #Création du dictionnaire
    with open(IDKhierarchy_path,'r') as file_in:
        dicPath = {}
        ID=""
        hierarchy=""
        path=""
        line=file_in.readline()
        while line != "":
    #Enregistrement des valeurs ID
            ID=line.strip().split("\t")[0]
    #Enregistrement des clés
            hierarchy=line.strip().split("\t")[2]
            if hierarchy == "NA":
                pass
            else:
                path=hierarchy.strip().split(",")[0]         
                if path in dicPath:
                    dicPath[path]+=[ID]
                else:
                    dicPath[path]=[ID]
            line=file_in.readline()

    import csv
    Kpathlist = "Kpatlist.tsv"
    Kpathlist_path = results_path +"/"+ Kpathlist
    #Ouverture en écriture du fichier contenant la liste des pathways
    with open(Kpathlist_path,'w', newline='') as file_out:
        fields=["1","2","3"]
        file_writer=csv.DictWriter(file_out,fieldnames=fields,delimiter="\t",quotechar="",quoting=csv.QUOTE_NONE)
    # Ecriture dans le fichier de sortie
        for path in dicPath:
            file_writer.writerow({"1":path,"2":len(dicPath[path]),"3":dicPath[path]})
    print('job done !')

if __name__ == "__main__":
    print()
    results_path = "results"
    try:
        os.mkdir(results_path)
    except:
        pass
    path2list(results_path)       
